
import javax.swing.JOptionPane;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Add_Flight_Details extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    public Add_Flight_Details() {
        initComponents();
        conn=javaconnect.ConnectDb();
       Random();
        fetch();
    }
    
    public void Random(){
        Random rd=new Random();
        fid.setText(""+rd.nextInt(1000+1));
        
    }
    public void fetch(){
        try{
            String sql="select * from flight ";
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            jtable.setModel(DbUtils.resultSetToTableModel(rs));
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        fid = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        atime = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        dtime = new javax.swing.JTextField();
        fprice = new javax.swing.JTextField();
        Date = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Add_Flight = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        Search = new javax.swing.JButton();
        home = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        source = new javax.swing.JComboBox<>();
        dest = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Flight Id:");
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Flight Name:");
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Source:");
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Destination:");
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Date:");
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Arrival Time:");
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Departure Time:");
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Flight price:");
        jtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Flight Id", "Flight Name", "Source", "Destination", "Date", "Arrival Time", "Departure Time", "Flight Price"
            }
        ));
        jScrollPane1.setViewportView(jtable);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Add Flight Details");


        Add_Flight.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add_Flight.setText("Add");
        Add_Flight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_FlightActionPerformed(evt);
            }
        });

        Delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });

        home.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        home.setText("Home");
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        Exit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

    }
    private void Add_FlightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_FlightActionPerformed
        if((String)source.getSelectedItem()==(String)dest.getSelectedItem()){
             JOptionPane.showMessageDialog(null,"invalid entry" );
        }
        else{
                 DateFormat da=new SimpleDateFormat("yyy-MM-dd");
                 String date=da.format(Date.getDate());
            {
        try{
            String sql="insert into flight(Flight_Id,Flight_Name,Source,Destination,Date,Arrival_Time,Departure_Time,Flight_Price)values(?,?,?,?,?,?,?,?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, fid.getText());
            pst.setString(2, fname.getText());
            pst.setString(3, (String)source.getSelectedItem());
            pst.setString(4, (String)dest.getSelectedItem());
            pst.setString(5,date);
            pst.setString(6, atime.getText());
            pst.setString(7, dtime.getText());
            pst.setString(8, fprice.getText());       
            pst.execute();
            fetch();
             
            JOptionPane.showMessageDialog(null, "registered");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        }
        }
       
    }

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {
        String sql="DELETE FROM flight WHERE Flight_Id = ?";
        
            try {
                pst=conn.prepareStatement(sql);
                int id = Integer.parseInt(fid.getText());
                 
                    pst.setInt(1, id);
                    pst.executeUpdate();
                     fetch();
                    JOptionPane.showMessageDialog(null, "Flight Details Deleted");
                    
            } 
            catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
       
    }

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {
        DateFormat da=new SimpleDateFormat("yyy-MM-dd");
        String date=da.format(Date.getDate());
        try{
            String sql="update flight set Flight_Name=?, Source=?, Destination=?, Date=?, Arrival_Time=?, Departure_Time=?, Flight_Price=? where Flight_Id=?";
            pst=conn.prepareStatement(sql);
            pst.setString(8, fid.getText());
            pst.setString(1, fname.getText());
            pst.setString(2, (String)source.getSelectedItem());
            pst.setString(3, (String)dest.getSelectedItem());
            pst.setString(4,date);
            pst.setString(5, atime.getText());
            pst.setString(6, dtime.getText());
            pst.setString(7, fprice.getText());
            pst.executeUpdate();
             fetch();
            JOptionPane.showMessageDialog(null,"Update Successful");    
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {
        String sql="select * from flight where Flight_Id=?";
        try{
             pst=conn.prepareStatement(sql);
             pst.setString(1, fid.getText());
             rs=pst.executeQuery();
             if(rs.next()){
                 String add1=rs.getString("Flight_Name");
                 fname.setText(add1);
                 String add2=rs.getString("Source");
                 source.setSelectedItem(add2);
                 String add3=rs.getString("Destination");
                 dest.setSelectedItem(add3);
                 String Dob=rs.getString("Date");
                java.util.Date date1 =   new SimpleDateFormat("yyyy-MM-dd").parse(Dob);
                Date.setDate(date1);
                String add5=rs.getString("Arrival_Time");
                atime.setText(add5);
                String add6=rs.getString("Departure_Time");
                dtime.setText(add6);
                String add7=rs.getString("Flight_Price");
                fprice.setText(add7);
             }else{
                JOptionPane.showMessageDialog(null, "This flght id not registered");

            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {
        setVisible(false);
        Admin_frame ob=new Admin_frame();
        ob.setVisible(true);
      
    }

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {
        JFrame frame=new JFrame("EXIT");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","EXIT",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
        {
            System.exit(0);
        }
    }

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_Flight_Details().setVisible(true);
            }
        });
    }

    private javax.swing.JButton Add_Flight;
    private com.toedter.calendar.JDateChooser Date;
    private javax.swing.JButton Delete;
    private javax.swing.JButton Exit;
    private javax.swing.JButton Search;
    private javax.swing.JButton Update;
    private javax.swing.JTextField atime;
    private javax.swing.JComboBox<String> dest;
    private javax.swing.JTextField dtime;
    private javax.swing.JTextField fid;
    private javax.swing.JTextField fname;
    private javax.swing.JTextField fprice;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtable;
    private javax.swing.JComboBox<String> source;
}
